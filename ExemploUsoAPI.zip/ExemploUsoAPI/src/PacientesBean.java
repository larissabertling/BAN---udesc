/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rebeca
 */
public class PacientesBean {
    private int codp;
    private String nome;

    /**
     * @return the codp
     */
    public int getCodp() {
        return codp;
    }

    /**
     * @param codp the codp to set
     */
    public void setCodp(int codp) {
        this.codp = codp;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
}
